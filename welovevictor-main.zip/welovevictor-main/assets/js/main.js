function reason1() {
  document.getElementById("reason1").style.display = "none";
  document.getElementById("reason1h").style.display = "block";
  }

function reason2() {
  document.getElementById("reason2").style.display = "none";
  document.getElementById("reason2h").style.display = "block";
  }

function reason3() {
  document.getElementById("reason3").style.display = "none";
  document.getElementById("reason3h").style.display = "block";
  }

function reason4() {
  document.getElementById("reason4").style.display = "none";
  document.getElementById("reason4h").style.display = "block";
  }

function reason5() {
  document.getElementById("reason5").style.display = "none";
  document.getElementById("reason5h").style.display = "block";
  }

function reason6() {
  document.getElementById("reason6").style.display = "none";
  document.getElementById("reason6h").style.display = "block";
  }

  function reason7() {
  document.getElementById("reason7").style.display = "none";
  document.getElementById("reason7h").style.display = "block";
  }

function reason8() {
  document.getElementById("reason8").style.display = "none";
  document.getElementById("reason8h").style.display = "block";
  }

function reason9() {
  document.getElementById("reason9").style.display = "none";
  document.getElementById("reason9h").style.display = "block";
  }

function reason10() {
  document.getElementById("reason10").style.display = "none";
  document.getElementById("reason10h").style.display = "block";
  }

function reason11() {
  document.getElementById("reason11").style.display = "none";
  document.getElementById("reason11h").style.display = "block";
  }

function reason12() {
  document.getElementById("reason12").style.display = "none";
  document.getElementById("reason12h").style.display = "block";
  }

function reason13() {
  document.getElementById("reason13").style.display = "none";
  document.getElementById("reason13h").style.display = "block";
  }

function reason14() {
  document.getElementById("reason14").style.display = "none";
  document.getElementById("reason14h").style.display = "block";
  }

function reason15() {
  document.getElementById("reason15").style.display = "none";
  document.getElementById("reason15h").style.display = "block";
  }

function reason16() {
  document.getElementById("reason16").style.display = "none";
  document.getElementById("reason16h").style.display = "block";
  }

function reason17() {
  document.getElementById("reason17").style.display = "none";
  document.getElementById("reason17h").style.display = "block";
  }

function reason18() {
  document.getElementById("reason18").style.display = "none";
  document.getElementById("reason18h").style.display = "block";
  }

function reason19() {
  document.getElementById("reason19").style.display = "none";
  document.getElementById("reason19h").style.display = "block";
  }

function reason20() {
  document.getElementById("reason20").style.display = "none";
  document.getElementById("reason20h").style.display = "block";
  }

function reason21() {
  document.getElementById("reason21").style.display = "none";
  document.getElementById("reason21h").style.display = "block";
  }

function reason22() {
  document.getElementById("reason22").style.display = "none";
  document.getElementById("reason22h").style.display = "block";
  }

function reason23() {
  document.getElementById("reason23").style.display = "none";
  document.getElementById("reason23h").style.display = "block";
  }

  function reason24() {
  document.getElementById("reason24").style.display = "none";
  document.getElementById("reason24h").style.display = "block";
  }

function reason25() {
  document.getElementById("reason25").style.display = "none";
  document.getElementById("reason25h").style.display = "block";
  }

function reason26() {
  document.getElementById("reason26").style.display = "none";
  document.getElementById("reason26h").style.display = "block";
  }

function reason27() {
  document.getElementById("reason27").style.display = "none";
  document.getElementById("reason27h").style.display = "block";
  }

function reason28() {
  document.getElementById("reason28").style.display = "none";
  document.getElementById("reason28h").style.display = "block";
  }

function reason29() {
  document.getElementById("reason29").style.display = "none";
  document.getElementById("reason29h").style.display = "block";
  }

function reason30() {
  document.getElementById("reason30").style.display = "none";
  document.getElementById("reason30h").style.display = "block";
  }
